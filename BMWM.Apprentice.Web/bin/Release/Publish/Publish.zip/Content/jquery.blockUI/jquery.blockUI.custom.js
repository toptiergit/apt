$.blockUI.defaults.message = "<i class='fa fa-spinner fa-spin bigger-200'></i>";
$.blockUI.defaults.baseZ = 2000;
$.blockUI.defaults.css.color = 'grey';
$.blockUI.defaults.css.border = 'none';
$.blockUI.defaults.css.backgroundColor = 'transparent';
